const AcademyService = require("./academyService");

module.exports = AcademyService;