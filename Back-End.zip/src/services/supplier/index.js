const SupplierService = require("./supplierService");

module.exports = {
  SupplierService,
};
