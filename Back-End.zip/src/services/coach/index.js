const coachService = require("./coachService");

module.exports = coachService;
