const userService = require("./userService");

module.exports = userService;
