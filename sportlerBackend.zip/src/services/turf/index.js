const turfService = require("./turfService")
const groundService = require("./groundService")
const slotGenerationService = require("./slotGenerationService")

module.exports = {
  turfService,
  groundService,
  slotGenerationService,
}
